export type Language =
  | 'javascript'
  | 'typescript'
  | 'python'
  | 'java'
  | 'cpp'
  | 'csharp'
  | 'go'
  | 'rust'
  | 'ruby'
  | 'php'
  | 'swift'
  | 'kotlin'
  | 'scala'
  | 'r'
  | 'sql'
  | 'html'
  | 'css'
  | 'xml'
  | 'yaml'
  | 'json';

export interface CodeError {
  line: number;
  message: string;
  severity: 'error' | 'warning';
  suggestion?: string;
}