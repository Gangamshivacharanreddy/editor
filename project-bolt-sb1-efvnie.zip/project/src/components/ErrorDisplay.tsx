import React from 'react';
import { CodeError } from '../types';

interface ErrorDisplayProps {
  errors: CodeError[];
}

const ErrorDisplay: React.FC<ErrorDisplayProps> = ({ errors }) => {
  if (errors.length === 0) return null;

  return (
    <div className="mt-4 space-y-2">
      {errors.map((error, index) => (
        <div
          key={index}
          className={`p-3 rounded ${
            error.severity === 'error' ? 'bg-red-50 text-red-700' : 'bg-yellow-50 text-yellow-700'
          }`}
        >
          <div className="flex items-start">
            <span className="font-medium">Line {error.line}:</span>
            <div className="ml-2">
              <p>{error.message}</p>
              {error.suggestion && (
                <p className="text-sm mt-1 opacity-80">
                  Suggestion: {error.suggestion}
                </p>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ErrorDisplay;