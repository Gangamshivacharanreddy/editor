import React, { useEffect, useCallback } from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import { Language, CodeError } from '../types';
import { validateCode, formatCode } from '../utils/codeValidation';
import ErrorDisplay from './ErrorDisplay';
import { autocompletion } from '@codemirror/autocomplete';
import { languageExtensions } from '../utils/languageExtensions';
import { getLanguageIcon } from '../utils/languageIcons';

interface CodeEditorProps {
  language: Language;
  value: string;
  onChange: (code: string) => void;
}

const CodeEditor: React.FC<CodeEditorProps> = ({ language, value, onChange }) => {
  const [errors, setErrors] = React.useState<CodeError[]>([]);
  const [isFormatting, setIsFormatting] = React.useState(false);

  const handleValidation = useCallback((code: string) => {
    const validationErrors = validateCode(code, language);
    setErrors(validationErrors);
  }, [language]);

  const handleChange = useCallback((value: string) => {
    onChange(value);
    handleValidation(value);
  }, [onChange, handleValidation]);

  const handleFormat = async () => {
    setIsFormatting(true);
    try {
      const formatted = await formatCode(value, language);
      onChange(formatted);
    } catch (error) {
      console.error('Format error:', error);
    }
    setIsFormatting(false);
  };

  const LanguageIcon = getLanguageIcon(language);

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center space-x-2">
          <LanguageIcon className="w-5 h-5 text-gray-600" />
          <span className="text-sm font-medium text-gray-700">
            {language.charAt(0).toUpperCase() + language.slice(1)}
          </span>
        </div>
        <button
          onClick={handleFormat}
          disabled={isFormatting}
          className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 transition-colors"
        >
          {isFormatting ? 'Formatting...' : 'Format Code'}
        </button>
      </div>
      <div className="relative">
        <CodeMirror
          value={value}
          height="400px"
          theme="dark"
          extensions={[
            languageExtensions[language] || javascript(),
            autocompletion(),
          ]}
          onChange={handleChange}
          className="text-sm"
          basicSetup={{
            lineNumbers: true,
            highlightActiveLineGutter: true,
            highlightSpecialChars: true,
            history: true,
            foldGutter: true,
            drawSelection: true,
            dropCursor: true,
            allowMultipleSelections: true,
            indentOnInput: true,
            syntaxHighlighting: true,
            bracketMatching: true,
            closeBrackets: true,
            autocompletion: true,
            rectangularSelection: true,
            crosshairCursor: true,
            highlightActiveLine: true,
            highlightSelectionMatches: true,
            closeBracketsKeymap: true,
            defaultKeymap: true,
            searchKeymap: true,
            historyKeymap: true,
            foldKeymap: true,
            completionKeymap: true,
            lintKeymap: true,
          }}
        />
      </div>
      <ErrorDisplay errors={errors} />
    </div>
  );
};

export default CodeEditor;