import { Language } from '../types';

export const defaultCode: Record<Language, string> = {
  javascript: `// JavaScript Example
function quickSort(arr) {
  if (arr.length <= 1) return arr;
  
  const pivot = arr[0];
  const left = arr.slice(1).filter(x => x < pivot);
  const right = arr.slice(1).filter(x => x >= pivot);
  
  return [...quickSort(left), pivot, ...quickSort(right)];
}

console.log(quickSort([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]));`,

  typescript: `// TypeScript Example
function mergeSort<T>(arr: T[]): T[] {
  if (arr.length <= 1) return arr;

  const mid = Math.floor(arr.length / 2);
  const left = arr.slice(0, mid);
  const right = arr.slice(mid);

  return merge(mergeSort(left), mergeSort(right));
}

function merge<T>(left: T[], right: T[]): T[] {
  const result: T[] = [];
  while (left.length && right.length) {
    result.push(left[0] <= right[0] ? left.shift()! : right.shift()!);
  }
  return [...result, ...left, ...right];
}`,

  python: `# Python Example
class BinarySearchTree:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None
    
    def insert(self, value):
        if value < self.value:
            if self.left is None:
                self.left = BinarySearchTree(value)
            else:
                self.left.insert(value)
        else:
            if self.right is None:
                self.right = BinarySearchTree(value)
            else:
                self.right.insert(value)

# Create and test BST
bst = BinarySearchTree(5)
for value in [3, 7, 1, 4, 6, 8]:
    bst.insert(value)`,

  java: `// Java Example
public class BubbleSort {
    public static void sort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // Swap arr[j] and arr[j+1]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
}`,

  cpp: `// C++ Example
#include <iostream>
#include <vector>

template<typename T>
class Stack {
private:
    std::vector<T> elements;
    
public:
    void push(T element) {
        elements.push_back(element);
    }
    
    T pop() {
        if (elements.empty()) {
            throw std::runtime_error("Stack is empty");
        }
        T element = elements.back();
        elements.pop_back();
        return element;
    }
    
    bool isEmpty() const {
        return elements.empty();
    }
};`,

  csharp: `// C# Example
public class LinkedList<T> {
    private class Node {
        public T Data { get; set; }
        public Node Next { get; set; }
        
        public Node(T data) {
            Data = data;
            Next = null;
        }
    }
    
    private Node head;
    
    public void Add(T data) {
        if (head == null) {
            head = new Node(data);
            return;
        }
        
        Node current = head;
        while (current.Next != null) {
            current = current.Next;
        }
        current.Next = new Node(data);
    }
}`,

  go: `// Go Example
package main

import "fmt"

type TreeNode struct {
    Value int
    Left  *TreeNode
    Right *TreeNode
}

func (t *TreeNode) Insert(value int) {
    if t == nil {
        t = &TreeNode{Value: value}
        return
    }
    
    if value < t.Value {
        if t.Left == nil {
            t.Left = &TreeNode{Value: value}
        } else {
            t.Left.Insert(value)
        }
    } else {
        if t.Right == nil {
            t.Right = &TreeNode{Value: value}
        } else {
            t.Right.Insert(value)
        }
    }
}`,

  rust: `// Rust Example
struct Queue<T> {
    elements: Vec<T>,
}

impl<T> Queue<T> {
    fn new() -> Self {
        Queue {
            elements: Vec::new(),
        }
    }
    
    fn enqueue(&mut self, element: T) {
        self.elements.push(element);
    }
    
    fn dequeue(&mut self) -> Option<T> {
        if self.elements.is_empty() {
            None
        } else {
            Some(self.elements.remove(0))
        }
    }
}`,

  ruby: `# Ruby Example
class Graph
  def initialize
    @vertices = {}
  end
  
  def add_vertex(vertex)
    @vertices[vertex] = [] unless @vertices.key?(vertex)
  end
  
  def add_edge(vertex1, vertex2)
    add_vertex(vertex1)
    add_vertex(vertex2)
    @vertices[vertex1] << vertex2
    @vertices[vertex2] << vertex1
  end
  
  def neighbors(vertex)
    @vertices[vertex] || []
  end
end`,

  php: `<?php
// PHP Example
class HashTable {
    private $table = array();
    private $size;
    
    public function __construct($size = 10) {
        $this->size = $size;
    }
    
    private function hash($key) {
        return crc32($key) % $this->size;
    }
    
    public function put($key, $value) {
        $index = $this->hash($key);
        if (!isset($this->table[$index])) {
            $this->table[$index] = array();
        }
        $this->table[$index][] = array($key, $value);
    }
    
    public function get($key) {
        $index = $this->hash($key);
        if (isset($this->table[$index])) {
            foreach ($this->table[$index] as $pair) {
                if ($pair[0] === $key) {
                    return $pair[1];
                }
            }
        }
        return null;
    }
}`,

  swift: `// Swift Example
class AVLTree<T: Comparable> {
    class Node {
        var value: T
        var left: Node?
        var right: Node?
        var height: Int
        
        init(_ value: T) {
            self.value = value
            self.height = 1
        }
    }
    
    private var root: Node?
    
    private func height(_ node: Node?) -> Int {
        return node?.height ?? 0
    }
    
    private func balance(_ node: Node?) -> Int {
        return height(node?.left) - height(node?.right)
    }
}`,

  kotlin: `// Kotlin Example
data class TreeNode<T>(
    var value: T,
    var left: TreeNode<T>? = null,
    var right: TreeNode<T>? = null
)

fun <T : Comparable<T>> TreeNode<T>.insert(value: T) {
    when {
        value < this.value -> {
            if (left == null) left = TreeNode(value)
            else left?.insert(value)
        }
        else -> {
            if (right == null) right = TreeNode(value)
            else right?.insert(value)
        }
    }
}`,

  scala: `// Scala Example
sealed trait BinaryTree[+A]
case object Empty extends BinaryTree[Nothing]
case class Node[A](
  value: A,
  left: BinaryTree[A],
  right: BinaryTree[A]
) extends BinaryTree[A]

object BinaryTree {
  def insert[A](tree: BinaryTree[A], value: A)(implicit ord: Ordering[A]): BinaryTree[A] = {
    tree match {
      case Empty => Node(value, Empty, Empty)
      case Node(v, l, r) =>
        if (ord.lt(value, v)) Node(v, insert(l, value), r)
        else Node(v, l, insert(r, value))
    }
  }
}`,

  r: `# R Example
# Implementation of k-means clustering
kmeans_clustering <- function(data, k, max_iterations = 100) {
  # Randomly initialize k centroids
  n <- nrow(data)
  centroids <- data[sample(1:n, k), ]
  
  for (i in 1:max_iterations) {
    # Assign points to nearest centroid
    distances <- matrix(NA, n, k)
    for (j in 1:k) {
      distances[, j] <- apply(data, 1, function(x) sum((x - centroids[j, ])^2))
    }
    clusters <- apply(distances, 1, which.min)
    
    # Update centroids
    new_centroids <- t(sapply(1:k, function(j) {
      colMeans(data[clusters == j, , drop = FALSE])
    }))
    
    # Check convergence
    if (all(centroids == new_centroids)) break
    centroids <- new_centroids
  }
  
  list(centroids = centroids, clusters = clusters)
}`,

  sql: `-- SQL Example
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE posts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    title VARCHAR(255) NOT NULL,
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Query to get all posts with their authors
SELECT 
    p.id,
    p.title,
    p.content,
    u.username as author,
    p.created_at
FROM posts p
JOIN users u ON p.user_id = u.id
ORDER BY p.created_at DESC;`,

  html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Layout Example</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section id="home">
            <h1>Welcome</h1>
            <p>This is a responsive layout example.</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Example Site</p>
    </footer>
</body>
</html>`,

  css: `/* CSS Example */
:root {
  --primary-color: #3498db;
  --secondary-color: #2ecc71;
  --text-color: #333;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 20px;
}

@media (max-width: 768px) {
  .container {
    padding: 10px;
  }
  
  .card {
    margin-bottom: 15px;
  }
}`,

  xml: `<?xml version="1.0" encoding="UTF-8"?>
<bookstore>
    <book category="fiction">
        <title>The Great Gatsby</title>
        <author>F. Scott Fitzgerald</author>
        <year>1925</year>
        <price>9.99</price>
    </book>
    <book category="non-fiction">
        <title>A Brief History of Time</title>
        <author>Stephen Hawking</author>
        <year>1988</year>
        <price>14.99</price>
    </book>
</bookstore>`,

  yaml: `# YAML Example
version: '3'
services:
  web:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./src:/usr/share/nginx/html
    environment:
      - NODE_ENV=production
    depends_on:
      - api
  
  api:
    build: ./api
    ports:
      - "3000:3000"
    environment:
      - DATABASE_URL=postgres://user:pass@db:5432/dbname
    depends_on:
      - db
  
  db:
    image: postgres:13
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=dbname`,

  json: `{
  "name": "Advanced Configuration Example",
  "version": "1.0.0",
  "config": {
    "server": {
      "port": 3000,
      "host": "localhost",
      "protocol": "https"
    },
    "database": {
      "type": "postgresql",
      "connection": {
        "host": "db.example.com",
        "port": 5432,
        "user": "admin",
        "password": "secret"
      },
      "pool": {
        "min": 5,
        "max": 20
      }
    },
    "cache": {
      "type": "redis",
      "ttl": 3600,
      "keys": {
        "prefix": "app:",
        "separator": ":"
      }
    }
  }
}`
};