import { 
  FileJson, 
  FileCode2,
  FileType,
  FileText,
  Hash,
  Database,
  Terminal,
  Braces,
  Code2
} from 'lucide-react';
import { Language } from '../types';

export const getLanguageIcon = (language: Language) => {
  const iconMap: Record<Language, any> = {
    javascript: FileCode2,
    typescript: FileType,
    python: FileText,
    java: Code2,
    cpp: Braces,
    csharp: Hash,
    go: Code2,
    rust: Terminal,
    ruby: Code2,
    php: FileCode2,
    swift: Code2,
    kotlin: Code2,
    scala: Code2,
    r: Terminal,
    sql: Database,
    html: FileCode2,
    css: FileCode2,
    xml: FileCode2,
    yaml: FileText,
    json: FileJson
  };

  return iconMap[language] || FileCode2;
};