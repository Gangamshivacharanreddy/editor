import { Language, CodeError } from '../types';
import prettier from 'prettier';

const validateBrackets = (code: string): CodeError[] => {
  const errors: CodeError[] = [];
  const stack: { char: string; line: number }[] = [];
  const lines = code.split('\n');
  const pairs: Record<string, string> = {
    '(': ')',
    '[': ']',
    '{': '}',
  };

  lines.forEach((line, lineIndex) => {
    [...line].forEach((char) => {
      if ('([{'.includes(char)) {
        stack.push({ char, line: lineIndex + 1 });
      } else if (')]}'.includes(char)) {
        const last = stack.pop();
        if (!last || pairs[last.char] !== char) {
          errors.push({
            line: lineIndex + 1,
            message: `Mismatched bracket: ${char}`,
            severity: 'error',
            suggestion: `Expected matching pair for ${last?.char || char}`,
          });
        }
      }
    });
  });

  stack.forEach((item) => {
    errors.push({
      line: item.line,
      message: `Unclosed bracket: ${item.char}`,
      severity: 'error',
      suggestion: `Add closing ${pairs[item.char]} bracket`,
    });
  });

  return errors;
};

const validateIndentation = (code: string, language: Language): CodeError[] => {
  const errors: CodeError[] = [];
  const lines = code.split('\n');
  let expectedIndent = 0;

  const indentSize = language === 'python' ? 4 : 2;
  
  lines.forEach((line, index) => {
    const trimmedLine = line.trim();
    if (!trimmedLine) return;

    const currentIndent = line.search(/\S/);
    if (currentIndent % indentSize !== 0) {
      errors.push({
        line: index + 1,
        message: `Invalid indentation`,
        severity: 'warning',
        suggestion: `Use ${indentSize} spaces for indentation`,
      });
    }

    if (currentIndent < expectedIndent) {
      errors.push({
        line: index + 1,
        message: 'Incorrect indentation level',
        severity: 'warning',
        suggestion: `Expected indentation of ${expectedIndent} spaces`,
      });
    }

    // Update expected indentation for next line
    if (trimmedLine.endsWith('{') || trimmedLine.endsWith(':')) {
      expectedIndent = currentIndent + indentSize;
    } else if (trimmedLine === '}') {
      expectedIndent = Math.max(0, currentIndent - indentSize);
    }
  });

  return errors;
};

const validateSyntax = (code: string, language: Language): CodeError[] => {
  const errors: CodeError[] = [];
  const lines = code.split('\n');

  lines.forEach((line, index) => {
    // Language-specific syntax checks
    switch (language) {
      case 'javascript':
      case 'typescript':
        if (line.includes('console.log') && !line.includes(';')) {
          errors.push({
            line: index + 1,
            message: 'Missing semicolon',
            severity: 'error',
            suggestion: 'Add ; at the end of the line',
          });
        }
        break;

      case 'python':
        if (line.includes('print') && line.includes(';')) {
          errors.push({
            line: index + 1,
            message: 'Unnecessary semicolon in Python',
            severity: 'warning',
            suggestion: 'Remove the semicolon',
          });
        }
        break;

      case 'java':
      case 'cpp':
        if ((line.includes('class') || line.includes('void')) && !line.includes('{')) {
          errors.push({
            line: index + 1,
            message: 'Missing opening brace',
            severity: 'error',
            suggestion: 'Add { after the declaration',
          });
        }
        break;
    }
  });

  return errors;
};

export const formatCode = async (code: string, language: Language): Promise<string> => {
  try {
    const parser = language === 'javascript' || language === 'typescript' 
      ? 'babel'
      : language === 'css' 
      ? 'css'
      : language === 'html' 
      ? 'html'
      : 'babel';

    return prettier.format(code, {
      parser,
      semi: true,
      singleQuote: true,
      tabWidth: 2,
    });
  } catch {
    return code;
  }
};

export const validateCode = (code: string, language: Language): CodeError[] => {
  const bracketErrors = validateBrackets(code);
  const indentationErrors = validateIndentation(code, language);
  const syntaxErrors = validateSyntax(code, language);

  return [...bracketErrors, ...indentationErrors, ...syntaxErrors];
};