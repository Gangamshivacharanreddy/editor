import { javascript } from '@codemirror/lang-javascript';
import { Language } from '../types';
import { Extension } from '@codemirror/state';

export const languageExtensions: Partial<Record<Language, Extension>> = {
  javascript: javascript({ jsx: true }),
  typescript: javascript({ typescript: true }),
  // Add more language extensions as needed
};