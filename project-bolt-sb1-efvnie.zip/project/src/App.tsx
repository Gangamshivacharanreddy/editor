import React, { useState } from 'react';
import { GithubIcon } from 'lucide-react';
import CodeEditor from './components/CodeEditor';
import LanguageSelector from './components/LanguageSelector';
import { Language } from './types';
import { defaultCode } from './utils/defaultCode';

function App() {
  const [language, setLanguage] = useState<Language>('javascript');
  const [code, setCode] = useState(defaultCode[language]);

  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage);
    setCode(defaultCode[newLanguage]);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-6">
        <header className="mb-8">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold text-gray-900">Code Syntax Highlighter</h1>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-gray-900"
            >
              <GithubIcon className="w-6 h-6" />
            </a>
          </div>
          <p className="mt-2 text-gray-600">
            A lightweight code editor with syntax highlighting and error detection.
          </p>
        </header>

        <main className="bg-white rounded-lg shadow-lg p-6">
          <LanguageSelector
            selectedLanguage={language}
            onLanguageChange={handleLanguageChange}
          />
          <CodeEditor
            language={language}
            value={code}
            onChange={setCode}
          />
          <div className="mt-4 text-sm text-gray-500">
            <p>Start typing or paste your code above to see syntax highlighting and error detection in action.</p>
          </div>
        </main>

        <footer className="mt-8 text-center text-gray-500 text-sm">
          <p>Built with React, TypeScript, and Prism.js</p>
        </footer>
      </div>
    </div>
  );
}

export default App;